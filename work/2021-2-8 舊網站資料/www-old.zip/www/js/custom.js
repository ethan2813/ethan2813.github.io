(function ($) {

    "use strict";

        // PRE LOADER
        $(window).load(function(){
          $('.preloader').fadeOut(1000); // set duration in brackets    
        });


        // navigation Section
        $('.navbar-collapse a').on('click',function(){
          $(".navbar-collapse").collapse('hide');
        });


        // Parallax Js
        function initParallax() {
          $('#home').parallax("20%", 10);
          $('#service').parallax("50%", 40);
          $('#about').parallax("50%", 20);
          $('#work').parallax("50%", 30);
          $('#contact').parallax("50%", 10);
          }
        initParallax();
        

        // smoothscroll js
        // $(function() {
        //   $('#home a').bind('click', function(event) {
        //     var $anchor = $(this);
        //     $('html, body').stop().animate({
        //         scrollTop: $($anchor.attr('href')).offset().top - 49
        //     }, 1000);
        //     event.preventDefault();
        //   });
        // });  


        // WOW Animation js
        new WOW({ mobile: false }).init();

})(jQuery);



$(document).ready(function() {
  // carousel plugin initialization
  $('.owl-carousel').owlCarousel({
      loop:true,
      margin:16,
      nav:false,
      navText:[],
      dots: true,
      responsive:{
          0:{
              items:1
          },
          480:{
              items:1
          },
          768:{
              items:2
          },
          1600:{
              items:3
          }
      }
  })
});